// ═══════════════════════════════════════════════════════════════
// Vyapai CRM — Backend Server (Node.js + Express + OpenAI)
// Sudarshan AI Labs | vyapai.in
// Deploy on: Vercel / Render / Netlify Functions
// ═══════════════════════════════════════════════════════════════

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { createClient } = require("@supabase/supabase-js");
const OpenAI = require("openai");

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json());

// ── Clients ────────────────────────────────────────────────────
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ── System prompt for Hindi CRM Agent ──────────────────────────
const SYSTEM_PROMPT = `
Tu Vyapai AI hai — ek expert Hindi/Hinglish CRM aur accounting assistant for Indian MSMEs.
Tujhe Sudarshan Traders (Lucknow) ke liye business decisions mein help karni hai.

Rules:
1. Hamesha Hinglish mein jawab de (Hindi + English mix). 
2. Business-focused, short, aur actionable replies do.
3. Amounts ₹ symbol ke saath likho, Indian format mein (e.g., ₹1,42,500).
4. "ji" se respectfully baat karo.
5. JSON format mein action return karo jab data operation ho.
6. Har reply mein ek concrete next step suggest karo.

Action JSON format:
{
  "action": "GET_BALANCE | ADD_CUSTOMER | CREATE_INVOICE | ADD_PAYMENT | CREATE_TASK | QUERY_TASKS | QUERY_INVOICES | GET_INSIGHTS",
  "parameters": { ... },
  "reply": "Hinglish mein reply...",
  "next_step": "Agle kaam ka suggestion..."
}
`;

const INSIGHTS_PROMPT = `
Tu Vyapai AI Business Advisor hai. Neeche diye gaye MSME business data ke basis pe:
1. 3 Voice Insights do — short, powerful Hindi sentences jo owner ko turant samajh aaye.
2. 5 Action Points do — specific, doable, aaj ke liye.

Data:
{DATA}

Response format (JSON only, no markdown):
{
  "voice_insights": [
    { "hindi": "...", "english": "...", "icon": "emoji", "type": "warning|success|info" }
  ],
  "action_points": [
    { "hindi": "...", "english": "...", "priority": "high|medium|low", "category": "collections|sales|expense|followup|growth", "icon": "emoji" }
  ]
}
`;

// ════════════════════════════════════════════
// ROUTES
// ════════════════════════════════════════════

// Health check
app.get("/", (req, res) => res.json({ status: "ok", app: "Vyapai CRM API", version: "2.0" }));

// ── POST /chat-crm — Text AI Agent ─────────────────────────────
app.post("/chat-crm", async (req, res) => {
  try {
    const { message, history = [], org_id } = req.body;
    if (!message) return res.status(400).json({ error: "message required" });

    // Build context from Supabase
    let context = "";
    if (org_id) {
      const { data: inv } = await supabase
        .from("invoices")
        .select("total_amount, paid_amount, status")
        .eq("org_id", org_id)
        .neq("status", "Paid");
      const totalDue = inv?.reduce((s, i) => s + (i.total_amount - i.paid_amount), 0) || 0;
      context = `\nLive context: Total pending = ₹${totalDue.toLocaleString("en-IN")}`;
    }

    const messages = [
      ...history.map((h) => ({ role: h.role, content: h.text })),
      { role: "user", content: message + context },
    ];

    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o",
      messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
      max_tokens: 600,
      temperature: 0.7,
    });

    const reply = completion.choices[0].message.content;
    res.json({ reply, tokens: completion.usage?.total_tokens });
  } catch (err) {
    console.error("/chat-crm error:", err);
    res.status(500).json({ error: "AI error", detail: err.message });
  }
});

// ── POST /voice-agent — Voice AI Agent ─────────────────────────
app.post("/voice-agent", async (req, res) => {
  try {
    const { transcript, org_id } = req.body;
    if (!transcript) return res.status(400).json({ error: "transcript required" });

    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: `Voice input: "${transcript}"\nOrg: ${org_id || "default"}` },
      ],
      max_tokens: 400,
      temperature: 0.5,
    });

    const raw = completion.choices[0].message.content;
    let parsed = null;
    try { parsed = JSON.parse(raw); } catch { /* not JSON */ }

    if (parsed?.action) {
      await executeAction(parsed, org_id, res);
    } else {
      res.json({ reply: raw, action: null });
    }
  } catch (err) {
    console.error("/voice-agent error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /insights — AI Business Insights ──────────────────────
app.post("/insights", async (req, res) => {
  try {
    const { org_id } = req.body;

    // Fetch live data from Supabase
    const [invRes, custRes, expRes, taskRes] = await Promise.all([
      supabase.from("invoices").select("status, total_amount, paid_amount, due_date").eq("org_id", org_id),
      supabase.from("customers").select("customer_id, is_active").eq("org_id", org_id),
      supabase.from("expenses").select("amount, category").eq("org_id", org_id).gte("date", new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString()),
      supabase.from("tasks").select("status, due_date").eq("org_id", org_id).eq("status", "Pending"),
    ]);

    const invoices = invRes.data || [];
    const totalDue = invoices.filter(i => i.status !== "Paid").reduce((s, i) => s + (i.total_amount - i.paid_amount), 0);
    const overdue = invoices.filter(i => i.status === "Overdue").length;
    const totalExp = (expRes.data || []).reduce((s, e) => s + e.amount, 0);

    const dataContext = JSON.stringify({
      total_pending_amount: totalDue,
      overdue_invoices: overdue,
      active_customers: (custRes.data || []).filter(c => c.is_active).length,
      pending_tasks: (taskRes.data || []).length,
      this_month_expenses: totalExp,
    });

    const prompt = INSIGHTS_PROMPT.replace("{DATA}", dataContext);

    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1200,
      temperature: 0.6,
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(completion.choices[0].message.content);
    res.json(result);
  } catch (err) {
    console.error("/insights error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /customers — Add Customer ─────────────────────────────
app.post("/customers", async (req, res) => {
  try {
    const { org_id, business_name, owner_name, phone, city, category, gstin } = req.body;
    if (!business_name || !org_id) return res.status(400).json({ error: "business_name and org_id required" });

    const { data, error } = await supabase
      .from("customers")
      .insert([{ org_id, business_name, owner_name, phone, city, category: category || "Kirana", gstin }])
      .select()
      .single();

    if (error) throw error;
    res.json({ success: true, customer: data, message: `${business_name} ko CRM mein jod diya gaya ji! ✅` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /customers — List Customers ────────────────────────────
app.get("/customers", async (req, res) => {
  try {
    const { org_id } = req.query;
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .eq("org_id", org_id)
      .eq("is_active", true)
      .order("created_at", { ascending: false });
    if (error) throw error;
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /invoices — Create Invoice ────────────────────────────
app.post("/invoices", async (req, res) => {
  try {
    const { org_id, customer_id, items = [], notes, due_date } = req.body;
    const subtotal = items.reduce((s, i) => s + i.line_total, 0);
    const cgst = subtotal * 0.09;
    const sgst = subtotal * 0.09;
    const total = subtotal + cgst + sgst;

    const invNum = "INV-" + Date.now().toString().slice(-5);

    const { data: inv, error: invErr } = await supabase
      .from("invoices")
      .insert([{ org_id, customer_id, invoice_number: invNum, subtotal, cgst_amount: cgst, sgst_amount: sgst, total_amount: total, notes, due_date }])
      .select()
      .single();

    if (invErr) throw invErr;

    if (items.length > 0) {
      await supabase.from("invoice_items").insert(items.map(i => ({ ...i, invoice_id: inv.invoice_id })));
    }

    res.json({ success: true, invoice: inv, message: `Bill ${invNum} (${formatInr(total)}) create ho gaya! ✅` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /payments — Record Payment ────────────────────────────
app.post("/payments", async (req, res) => {
  try {
    const { org_id, invoice_id, amount, payment_mode, reference_no } = req.body;
    const { data, error } = await supabase
      .from("payments")
      .insert([{ org_id, invoice_id, amount, payment_mode: payment_mode || "UPI", reference_no }])
      .select()
      .single();
    if (error) throw error;
    res.json({ success: true, payment: data, message: `₹${Number(amount).toLocaleString("en-IN")} payment record ho gaya! ✅` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /expenses — Add Expense ───────────────────────────────
app.post("/expenses", async (req, res) => {
  try {
    const { org_id, amount, category, vendor, notes, date } = req.body;
    const { data, error } = await supabase
      .from("expenses")
      .insert([{ org_id, amount, category: category || "Other", vendor, notes, date: date || new Date().toISOString().split("T")[0] }])
      .select()
      .single();
    if (error) throw error;
    res.json({ success: true, expense: data, message: `Kharch record ho gaya ji! ✅` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /tasks — Create Task ───────────────────────────────────
app.post("/tasks", async (req, res) => {
  try {
    const { org_id, title, customer_id, due_date, priority } = req.body;
    const { data, error } = await supabase
      .from("tasks")
      .insert([{ org_id, title, customer_id, due_date, priority: priority || "Medium" }])
      .select()
      .single();
    if (error) throw error;
    res.json({ success: true, task: data, message: `Task "${title}" add ho gaya! ✅` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /dashboard — Dashboard KPIs ────────────────────────────
app.get("/dashboard", async (req, res) => {
  try {
    const { org_id } = req.query;
    const today = new Date().toISOString().split("T")[0];

    const [invRes, custRes, taskRes, payRes] = await Promise.all([
      supabase.from("invoices").select("total_amount, paid_amount, status").eq("org_id", org_id),
      supabase.from("customers").select("customer_id").eq("org_id", org_id).eq("is_active", true),
      supabase.from("tasks").select("task_id").eq("org_id", org_id).eq("status", "Pending").lte("due_date", today + "T23:59:59"),
      supabase.from("payments").select("amount").eq("org_id", org_id).gte("date", today),
    ]);

    const invoices = invRes.data || [];
    const totalDue = invoices.filter(i => i.status !== "Paid").reduce((s, i) => s + (i.total_amount - i.paid_amount), 0);
    const todayCollection = (payRes.data || []).reduce((s, p) => s + p.amount, 0);

    res.json({
      totalDue,
      todayCollection,
      activeCustomers: (custRes.data || []).length,
      todayFollowups: (taskRes.data || []).length,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Helper: execute AI action against DB ──────────────────────
async function executeAction(parsed, org_id, res) {
  const { action, parameters, reply } = parsed;
  let dbResult = null;

  switch (action) {
    case "GET_BALANCE": {
      const name = parameters?.customer_name;
      const { data } = await supabase
        .from("invoices")
        .select("total_amount, paid_amount, customers(business_name)")
        .eq("org_id", org_id)
        .neq("status", "Paid")
        .ilike("customers.business_name", `%${name}%`);
      const balance = (data || []).reduce((s, i) => s + (i.total_amount - i.paid_amount), 0);
      dbResult = { balance, customer: name };
      break;
    }
    case "ADD_CUSTOMER": {
      const { data } = await supabase.from("customers").insert([{ org_id, ...parameters }]).select().single();
      dbResult = data;
      break;
    }
    case "QUERY_TASKS": {
      const { data } = await supabase.from("tasks").select("*, customers(business_name)").eq("org_id", org_id).eq("status", "Pending");
      dbResult = data;
      break;
    }
    default:
      dbResult = null;
  }

  res.json({ reply, action, dbResult });
}

function formatInr(n) { return "₹" + Number(n).toLocaleString("en-IN"); }

// ── Start server ────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`✅ Vyapai CRM Backend running on port ${PORT}`));

module.exports = app;
